import pandas as pd

class ReportGenerator:
    @staticmethod
    def generate_summary(summary_data):
        try:
            if not summary_data:
                return "No student data analyzed yet. Please run analyze_content first."

            summary_report = "School Assessment Summary Report:\n\n"

            for student in summary_data:
                summary_report += f"1. Overall Performance of {student.get('Name', 'Unknown')}:\n"
                summary_report += f"   - Average score: {student.get('Average_Score', 'N/A'):.1f}\n"
                summary_report += f"   - Top-performing class: {student.get('Top_Performing_Class', 'N/A')}\n\n"

                summary_report += "2. Subject-wise Analysis:\n"
                subject_analysis = student.get('Subject_Analysis', {})
                for subject, analysis in subject_analysis.items():
                    summary_report += f"   - {subject}: {analysis}\n"
                summary_report += "\n"

                summary_report += "3. Notable Observations:\n"
                summary_report += f"   - {student.get('Notable_Observation', 'N/A')}\n\n"

                summary_report += "4. Web Data Insights:\n"
                summary_report += f"   - Online participation: {student.get('Online_Participation', 'N/A')}% of students accessed assessment resources online.\n\n"

                summary_report += "5. Recommendations:\n"
                summary_report += f"   - {student.get('Recommendations', 'N/A')}\n\n"

            summary_report += f"Report generated on: {pd.Timestamp.now().strftime('%Y-%m-%d')}\n"

            return summary_report
        except Exception as e:
            print(f"An error occurred while generating the summary: {e}")
            return ""

    @classmethod
    def save_summary_to_file(cls, summary, file_name):
        try:
            with open(file_name, 'w') as file:
                file.write(summary)
            print(f"Summary saved to {file_name}.")
        except Exception as e:
            print(f"An error occurred while saving the summary to file: {e}")

# Example of how to use this class
if __name__ == "__main__":
    example_summary = "This is an example summary."
    ReportGenerator.save_summary_to_file(example_summary, 'example_summary.txt')
