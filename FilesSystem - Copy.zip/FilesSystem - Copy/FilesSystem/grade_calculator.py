import pandas as pd
from urllib.request import urlopen
from bs4 import BeautifulSoup

class GradeCalculator:
    @staticmethod
    def determine_grade(avg_score):
        if avg_score > 89:
            return 'A'
        elif avg_score > 79:
            return 'B'
        elif avg_score > 69:
            return 'C'
        elif avg_score > 59:
            return 'D'
        else:
            return 'F'

class SchoolAssessmentAnalyzer:
    def __init__(self):
        self.data = pd.DataFrame()

    def process_file(self, file_path):
        try:
            if file_path.endswith('.csv'):
                self.data = pd.read_csv(file_path)
            elif file_path.endswith('.xlsx'):
                self.data = pd.read_excel(file_path)
            elif file_path.endswith('.txt'):
                with open(file_path, 'r') as file:
                    self.data = pd.read_csv(file)
            else:
                raise ValueError("Unsupported file format.")
            print(f"File {file_path} processed successfully.")
        except Exception as e:
            print(f"An error occurred while processing the file: {e}")

    def analyze_content(self):
        try:
            # Make sure to use the correct columns for calculation
            if 'Average_Score' not in self.data.columns:
                subject_columns = ['Math', 'English', 'Science']  # Adjust these if needed
                if all(col in self.data.columns for col in subject_columns):
                    self.data['Average_Score'] = self.data[subject_columns].mean(axis=1)
                else:
                    print(f"Expected columns {subject_columns} are not present in the data.")
                    return
            print("Content analysis completed successfully.")
        except Exception as e:
            print(f"An error occurred during content analysis: {e}")

    def transfer_data(self, criteria, source_file, destination_file):
        try:
            # Process the source file first
            self.process_file(source_file)
            # Analyze content to ensure 'Average_Score' is created
            self.analyze_content()
            # Filter data based on the provided criteria
            filtered_data = self.data.query(criteria)
            # Save the filtered data to a new CSV file
            filtered_data.to_csv(destination_file, index=False)
            print(f"Data successfully transferred to {destination_file}.")
        except Exception as e:
            print(f"An error occurred during data transfer: {e}")

    def fetch_web_data(self, url):
        try:
            with urlopen(url) as response:
                html_content = response.read()
                soup = BeautifulSoup(html_content, 'html.parser')
                # Assuming we want to extract a specific content, e.g., a table
                table = soup.find('table')
                table_data = []
                if table:
                    for row in table.find_all('tr'):
                        cols = row.find_all('td')
                        cols = [ele.text.strip() for ele in cols]
                        table_data.append(cols)
                    # Convert the table data into a DataFrame
                    self.data = pd.DataFrame(table_data[1:], columns=table_data[0])
                    print("Web data fetched and stored successfully.")
                else:
                    print("No table found in the webpage.")
        except Exception as e:
            print(f"An error occurred while fetching web data: {e}")

    def generate_summary(self):
        try:
            if 'Average_Score' not in self.data.columns:
                print("Error: 'Average_Score' column not found. Please run analyze_content first.")
                return ""
            summary = "School Assessment Summary:\n"
            top_performers = self.data[self.data['Average_Score'] > 90]
            summary += f"Top Performers: {len(top_performers)} students\n\n"
            for _, row in top_performers.iterrows():
                summary += f"Name: {row['Name']}, Average Score: {row['Average_Score']:.2f}\n"
            return summary
        except Exception as e:
            print(f"An error occurred while generating the summary: {e}")
            return ""

    def analyze_student(self, student_name):
        try:
            student_data = self.data[self.data['Name'].str.lower() == student_name.lower()]
            if not student_data.empty:
                avg_score = student_data['Average_Score'].values[0]
                grade = GradeCalculator.determine_grade(avg_score)
                return f"Student: {student_name}\nAverage Score: {avg_score:.2f}\nGrade: {grade}\n"
            else:
                return f"No data found for student: {student_name}\n"
        except Exception as e:
            print(f"An error occurred while analyzing the student: {e}")
            return ""

# Example usage
analyzer = SchoolAssessmentAnalyzer()

# Process files
analyzer.process_file('school_management.csv')
analyzer.process_file('all_semester.csv')

# Analyze content
analyzer.analyze_content()  # Ensure content is analyzed before proceeding

# Transfer data
analyzer.transfer_data('Average_Score > 90', 'school_management.csv', 'high_achievers.csv')

# Fetch web data
analyzer.fetch_web_data('https://schoolwebsite.com/assessment')

# Generate summary
summary = analyzer.generate_summary()
print(summary)

# Analyze individual students
try:
    while True:
        student_name = input("Enter student name (or type 'exit' to quit): ")
        if student_name.lower() == 'exit':
            break

        student_summary = analyzer.analyze_student(student_name)
        print(student_summary)
except Exception as e:
    print(f"An unexpected error occurred: {e}")
