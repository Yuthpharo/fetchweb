from schoolassesmentanalyzer import SchoolAssessmentAnalyzer
from report_generator import ReportGenerator

def main():
    analyzer = SchoolAssessmentAnalyzer()

    # Process files
    analyzer.process_file('school_management.csv')
    analyzer.process_file('all_semester.csv')

    # Analyze content
    analyzer.analyze_content()

    # Transfer data
    analyzer.transfer_data('Average_Score > 90', 'school_management.csv', 'high_achievers.csv')

    # Fetch web data
    analyzer.fetch_web_data('https://schoolwebsite.com/assessment')

    # Generate overall summary
    overall_summary = analyzer.generate_summary()
    print("Overall Summary:\n")
    print(overall_summary)

    # Save the overall summary to a file
    ReportGenerator.save_summary_to_file(overall_summary, 'assessment_summary_report.txt')

    # Analyze individual students
    try:
        while True:
            student_name = input("Enter student name (or type 'exit' to quit): ")
            if student_name.lower() == 'exit':
                break

            student_data = analyzer.analyze_student(student_name)
            if student_data:
                student_summary = ReportGenerator.generate_summary([student_data])
                print(f"\nSummary for {student_name}:\n")
                print(student_summary)
                # Save the individual student summary to the file
                ReportGenerator.save_summary_to_file(student_summary, 'assessment_summary_report.txt')
            else:
                print(f"No data found for student: {student_name}")

    except Exception as e:
        print(f"An unexpected error occurred: {e}")

if __name__ == "__main__":
    main()
